This app was created from the SalesforceMobileSDK Native Rest App template.

The login host can be configured in system Settings on the device:
You can switch between Production, Sandbox, or a custom host if needed.

In addition, selecting Logout in Settings will force your application to logout of the current Salesforce account the next time the app is launched.

Please enjoy!
